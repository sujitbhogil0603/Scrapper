# Scrapper
Scrapper for internship

The program will scrape the products and save them in a CSV file named `data-{datetime}.csv` in the directory.
## Running
run the `main.py` file.
## Features

- Scrape products from Amazon.in with the given URL and retrieve the ASIN, name, rating, and number of ratings.
- Can be run for multiple pages to get more products.
- Export the data to a CSV file.
- any attribues can be scrapped like this.
- part 2 of assignment feels redundant since im already scrapping data from a page so doing it more times doesnt prove a point? because the same code can run for multiple products using a loop.

